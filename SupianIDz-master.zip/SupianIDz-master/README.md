<img align="right" src="assets/programming.gif" width="30%">

# Hi, i'm Supian M <img src="https://media.giphy.com/media/mGcNjsfWAjY5AEZNw6/giphy.gif" width="50">

I am an ordinary man who is stuck becoming a programmer accidentally. I am very interested in framework, cloud computing and open source.

Currently working as a web developer and sysadmin in government agencies.

You can see the results of my public work on this profile page or on [@OctopyID](https://github.com/OctopyID).
